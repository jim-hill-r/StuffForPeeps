RL_Project3
8803 Reinforcement Learning - Project 3

PRESENTATION LINK: http://youtu.be/7-2EodaBMsg?hd=1

GITHUB LINK: https://github.gatech.edu/jhill302/RL_Project3

HOW TO RUN THE CODE: There are two methods to run the code:

1) There are four executable jar files. One for each algorithm. In command prompt or terminal, navigate to the folder and run:
java -jar jhill302_project3_traditionalQ.jar
java -jar jhill302_project3_friendQ.jar
java -jar jhill302_project3_foeQ.jar
java -jar jhill302_project3_utilitarian.jar

2) If that is unsuccessful, you can import the whole project into Eclipse and run from there. The Project3.java has a main method that will run the experiments.

The results get put in the a subfolder called Results. If this folder doesn't exist, the software may crash.

ADDITIONAL NOTES:

TradQ_alpha_0p001.xlsx has the results presented in the paper in an excel file if needed for reference
FriendQ_alpha_0p001.xlsx has the results presented in the paper in an excel file if needed for reference
FoeQ_alpha_0p001_prob_10.xlsx has the results presented in the paper in an excel file if needed for reference
Util_alpha_0p001_prob_4.xlsx has the results presented in the paper in an excel file if needed for reference
jhill302-report.pdf is the paper
If there are any issues, please email jhill302@gatech.edu or jimhill84@gmail.com.