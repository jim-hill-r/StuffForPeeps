package edu.gatech.rl.project3;

public interface SelectionFunction {

	public Value getValue(State state, QValue q);
	
}
