package edu.gatech.rl.project3;

public class NoDecay implements DecaySchedule {
	
	public Double decay(Double currentAlpha){
		return currentAlpha;
	}
}
