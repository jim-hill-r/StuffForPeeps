package edu.gatech.rl.project3;

public class MultiAgentUpdate implements QUpdate {

	private MarkovGame game;
	
	public MultiAgentUpdate(MarkovGame game){
		this.game = game;
	}
	
	public QValue initialQ(){
		return new QValue(this.game.getNumAgents(),this.game.getNumStates(), this.game.getNumActions());
	}
	
	public QValue getUpdate(State state, Action action, Reward reward, State nextState, Value value, QValue q, Double alpha, Double gamma){
		Integer n = this.game.getNumAgents();

		for(int i = 0; i<n; i++){
			Double memory = (1 - alpha) * q.get(i, state, action);
			Double discountedReward = (1 - gamma) * reward.get(i);
			Double valuePropogation = (gamma) * value.get(i, nextState);
			Double newQ = memory + (alpha) * (discountedReward + valuePropogation);
			q.set(i, state, action, newQ);
		}
				
		return q;
	}
}
