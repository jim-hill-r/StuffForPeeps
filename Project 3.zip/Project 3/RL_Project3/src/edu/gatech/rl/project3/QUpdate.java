package edu.gatech.rl.project3;

public interface QUpdate {

	public QValue initialQ();
	
	public QValue getUpdate(State state, Action action, Reward reward, State nextState, Value value, QValue q, Double alpha, Double gamma);
}
