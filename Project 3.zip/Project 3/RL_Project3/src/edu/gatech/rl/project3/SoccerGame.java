package edu.gatech.rl.project3;

import java.util.Random;

public class SoccerGame implements MarkovGame {
	
	private Random randomizer;
	
	private Integer NUM_AGENTS = 2;
	
	/*
	 *  0:  In row 1, col 1	without ball
	 *  1:  In row 1, col 2	without ball
	 *  2:  In row 1, col 3	without ball
	 *  3:  In row 1, col 4	without ball
	 *  4:  In row 2, col 1	without ball
	 *  5:  In row 2, col 2	without ball
	 *  6:  In row 2, col 3	without ball
	 *  7:  In row 2, col 4	without ball
	 *  8:  In row 1, col 1	with ball
	 *  9:  In row 1, col 2	with ball
	 *  10: In row 1, col 3	with ball
	 *  11: In row 1, col 4	with ball
	 *  12: In row 2, col 1	with ball
	 *  13: In row 2, col 2	with ball
	 *  14: In row 2, col 3	with ball
	 *  15: In row 2, col 4	with ball
	 */
	private Integer NUM_STATES = 16;
	
	/* 0: Stick
	 * 1: N
	 * 2: E
	 * 3: S
	 * 4: W
	 */
	private Integer NUM_ACTIONS = 5;
	
	public SoccerGame(){
		this.randomizer = new Random(1984L);
	}
	
	public State initialState(){
		State state = new State(this.NUM_AGENTS, this.NUM_STATES);
		state.set(1, 9);
		state.set(0, 2);
		return state;
	}
	
	public Integer getNumAgents(){
		return this.NUM_AGENTS;
	}
	
	public Integer getNumStates(){
		return this.NUM_STATES;
	}
	
	public Integer getNumActions(){
		return this.NUM_ACTIONS;
	}	
	
	public State simulate(State state, Action action){
		Integer startingPlayer = randomizer.nextInt(2);		
		Integer secondPlayer = 0;
		if(secondPlayer.equals(startingPlayer)){
			secondPlayer = 1;
		}
		
		State afterStartingPlayer = this.simulateSinglePlayer(startingPlayer, secondPlayer, state, action);
		if(afterStartingPlayer.isTerminal()){
			return afterStartingPlayer;
		}
		State nextState = this.simulateSinglePlayer(secondPlayer, startingPlayer, afterStartingPlayer, action);
		
		return nextState;
	}
	
	private State simulateSinglePlayer(Integer player, Integer otherPlayer, State state, Action action){

		Integer playerState = state.get(player);
		Integer playerAction = action.get(player);
		Integer otherState = state.get(otherPlayer);
		
		Integer playerLocation = this.convertStateToLocation(playerState);
		Boolean playerHasBall = this.convertStateToHasBall(playerState);
		Integer otherLocation = this.convertStateToLocation(otherState);
				
		if(playerAction.equals(1)){ // Player goes N
			if(playerLocation.equals(4)){
				if(otherLocation.equals(0)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 0;
				}
			}
			else if(playerLocation.equals(5)){
				if(otherLocation.equals(1)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 1;
				}
			}
			else if(playerLocation.equals(6)){
				if(otherLocation.equals(2)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 2;
				}
			}
			else if(playerLocation.equals(7)){
				if(otherLocation.equals(3)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 3;
				}
			}
		}
		else if(playerAction.equals(3)){ // Player goes S
			if(playerLocation.equals(0)){
				if(otherLocation.equals(4)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 4;
				}
			}
			else if(playerLocation.equals(1)){
				if(otherLocation.equals(5)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 5;
				}
			}
			else if(playerLocation.equals(2)){
				if(otherLocation.equals(6)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 6;
				}
			}
			else if(playerLocation.equals(3)){
				if(otherLocation.equals(7)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 7;
				}
			}
		}
		else if(playerAction.equals(2)){ // Player goes E
			if(playerLocation.equals(0)){
				if(otherLocation.equals(1)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 1;
				}
			}
			else if(playerLocation.equals(1)){
				if(otherLocation.equals(2)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 2;
				}
			}
			else if(playerLocation.equals(2)){
				if(otherLocation.equals(3)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 3;
				}
			}
			else if(playerLocation.equals(4)){
				if(otherLocation.equals(5)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 5;
				}
			}
			else if(playerLocation.equals(5)){
				if(otherLocation.equals(6)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 6;
				}
			}
			else if(playerLocation.equals(6)){
				if(otherLocation.equals(7)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 7;
				}
			}
		}
		else if(playerAction.equals(4)){ // Player goes W
			if(playerLocation.equals(3)){
				if(otherLocation.equals(2)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 2;
				}
			}
			else if(playerLocation.equals(2)){
				if(otherLocation.equals(1)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 1;
				}
			}
			else if(playerLocation.equals(1)){
				if(otherLocation.equals(0)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 0;
				}
			}
			else if(playerLocation.equals(7)){
				if(otherLocation.equals(6)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 6;
				}
			}
			else if(playerLocation.equals(6)){
				if(otherLocation.equals(5)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 5;
				}
			}
			else if(playerLocation.equals(5)){
				if(otherLocation.equals(4)){
					if(playerHasBall){
						playerHasBall = !playerHasBall;
					}
				}
				else{
					playerLocation = 4;
				}
			}
		}
		
		Integer nextPlayerState = this.convertLocationToState(playerLocation,playerHasBall);
		Integer nextOtherState = this.convertLocationToState(otherLocation,!playerHasBall);
		
		State nextState = state;
		nextState.set(player, nextPlayerState);
		nextState.set(otherPlayer, nextOtherState);
		
		if(nextPlayerState.equals(8) || nextPlayerState.equals(11) || nextPlayerState.equals(12) || nextPlayerState.equals(15)){
			nextState.setIsTerminal();
		}
		if(nextOtherState.equals(8) || nextOtherState.equals(11) || nextOtherState.equals(12) || nextOtherState.equals(15)){
			nextState.setIsTerminal();
		}
		return nextState;
	}
	
	private Integer convertStateToLocation(Integer state){
		if(state > 7){
			return state - 8;
		}
		return state;
	}
	
	private Boolean convertStateToHasBall(Integer state){
		if(state > 7){
			return true;
		}
		return false;
	}
	
	private Integer convertLocationToState(Integer location, Boolean hasBall){
		if(hasBall){
			return location + 8;
		}
		return location;
	}
	
	public Reward getReward(State state){
		Reward reward = new Reward(this.NUM_AGENTS);
		Integer playerOneState = state.get(0);
		Integer playerTwoState = state.get(1);
		if(playerOneState.equals(8) || playerOneState.equals(12)){
			reward.set(0, 100.0);
			reward.set(1, -100.0);
		}
		else if(playerOneState.equals(11) || playerOneState.equals(15)){
			reward.set(0, -100.0);
			reward.set(1, 100.0);
		}
		else if(playerTwoState.equals(8) || playerTwoState.equals(12)){
			reward.set(0, 100.0);
			reward.set(1, -100.0);
		}
		else if(playerTwoState.equals(11) || playerTwoState.equals(15)){
			reward.set(0, -100.0);
			reward.set(1, 100.0);
		}
		
		return reward;
	}
	
}
