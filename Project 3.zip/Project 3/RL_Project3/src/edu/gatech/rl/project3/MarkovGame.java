package edu.gatech.rl.project3;

public interface MarkovGame {
	
	public State initialState();
	
	public Integer getNumAgents();
	public Integer getNumStates();
	public Integer getNumActions();
	
	public State simulate(State currentState, Action action);
	
	public Reward getReward(State state);

}
