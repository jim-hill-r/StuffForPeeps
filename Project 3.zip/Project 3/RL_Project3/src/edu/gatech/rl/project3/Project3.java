package edu.gatech.rl.project3;

public class Project3 {

	public static void main(String[] args) {
		MarkovGame game = new SoccerGame();
		//SelectionFunction f = new TraditionalQ(game);
		SelectionFunction f = new FriendQ(game);
		//SelectionFunction f = new FoeQ(game);
		//SelectionFunction f = new Utilitarian(game);
		//QUpdate updateFunction = new TraditionalQUpdate(game);	
		QUpdate updateFunction = new MultiAgentUpdate(game);		
		ActionChooser randomAction = new RandomAction(game);
		DecaySchedule noDecay = new NoDecay();
		
		MultiQ qlearner = new MultiQ(game,f,updateFunction,randomAction,0.9,0.001,noDecay,1000000);
		
		Result result = qlearner.run();
		
		String filePath = System.getProperty("user.dir");
		filePath = filePath + "\\results\\result_" + Long.toString(System.currentTimeMillis()) + ".csv";
		result.write(0, filePath);

	}

}
