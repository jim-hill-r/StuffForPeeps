package edu.gatech.rl.project3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Result {
	
	private class SubResult {
		public Integer iteration;
		public Double prevValue;
		public Double currentValue;
		public Double error;
		
		public SubResult(Integer iter, Double prev, Double curr, Double err){
			this.iteration = iter;
			this.prevValue = prev;
			this.currentValue = curr;
			this.error = err;
		}
	}
	
	Map<Integer,List<SubResult>> results;
	
	public Result(){
		this.reset();
	}
	
	public void reset(){
		this.results = new HashMap<Integer,List<SubResult>>();
	}
	
	public void append(Integer agentIndex, Integer iteration, Double prevValue, Double currentValue){
		Double error = Math.abs(currentValue - prevValue);
		
		if(!this.results.containsKey(agentIndex)){
			this.results.put(agentIndex, new ArrayList<SubResult>());
		}
		SubResult newResult = new SubResult(iteration, prevValue, currentValue, error);
		List<SubResult> agentResults = this.results.get(agentIndex);
		agentResults.add(newResult);
	}
	
	public void write(Integer agentIndex, String filePath){
		try{
			Writer writer = new BufferedWriter(new FileWriter(filePath));
			writer.write("Iteration,error,prev,curr\n");
			List<SubResult> data = this.results.get(0);
			for(SubResult result : data){
				writer.write(result.iteration.toString() + "," + result.error.toString() + "," + result.prevValue.toString() + "," + result.currentValue.toString() + "\n");
			}
			writer.close();
		}
		catch(Exception e){
			
		}
		System.out.println("Wrote results to " + filePath);
	}
	

}
