package edu.gatech.rl.project3;

import java.util.Random;

public class RandomAction implements ActionChooser {

	private Random randomizer;
	
	private MarkovGame game;
	
	public RandomAction(MarkovGame game){
		this.game = game;
		this.randomizer = new Random(1984L);
	}
	
	public Action getAction(){
		Action action = new Action(this.game.getNumAgents(),this.game.getNumActions());
		for(int i=0;i<this.game.getNumAgents();i++){
			action.set(i, this.randomizer.nextInt(this.game.getNumActions()));
		}
		return action;
	}
	
}
