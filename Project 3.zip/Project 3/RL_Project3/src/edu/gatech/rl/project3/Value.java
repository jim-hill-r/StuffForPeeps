package edu.gatech.rl.project3;

import java.util.HashMap;
import java.util.Map;

public class Value {
	
	Map<Integer, Map<Integer, Double>> values;
	
	public Value(Integer numAgents, Integer numStates){
		this.values = new HashMap<Integer,Map<Integer,Double>>();
		for(int i=0; i<numAgents;i++){
			Map<Integer,Double> stateValues = new HashMap<Integer,Double>();
			Integer statePairs = (int) Math.pow(1.0*numStates, 1.0*numAgents);
			for(int j=0; j<statePairs;j++){
				stateValues.put(j, 0.0);
			}
			this.values.put(i, stateValues);
		}
	}

	public Double get(Integer agentIndex, State state){	
		Integer stateIndex = state.getId();
		return this.values.get(agentIndex).get(stateIndex);
	}
	
	public void set(Integer agentIndex, State state, Double newValue){
		Integer stateIndex = state.getId();
		Map<Integer,Double> stateValues = this.values.get(agentIndex);
		stateValues.put(stateIndex, newValue);
	}

}
