package edu.gatech.rl.project3;

public class TraditionalQ implements SelectionFunction {

	private MarkovGame game;
	
	public TraditionalQ(MarkovGame game){
		this.game = game;
	}
	
	public Value getValue(State state, QValue q){
		Value value = new Value(this.game.getNumAgents(),this.game.getNumStates());
		for(int i = 0; i<this.game.getNumAgents();i++){
			value.set(i, state, q.max(i, state));
		}
		return value;
	}
	
}
