package edu.gatech.rl.project3;

import java.util.HashMap;
import java.util.Map;

public class Reward {
	
	Map<Integer, Double> rewards;
	
	public Reward(Integer numAgents){
		this.rewards = new HashMap<Integer,Double>();
		for(int i=0; i<numAgents;i++){
			this.rewards.put(i,0.0);
		}
	}

	public Double get(Integer agentIndex){	
		return this.rewards.get(agentIndex);
	}
	
	public void set(Integer agentIndex, Double newReward){
		this.rewards.put(agentIndex, newReward);
	}
	
}
