package edu.gatech.rl.project3;

public class Utilitarian implements SelectionFunction {

	private MarkovGame game;
	private int NUM_PROBS;
	
	public Utilitarian(MarkovGame game){
		this.game = game;
		this.NUM_PROBS = 4;
	}
	
	public Value getValue(State state, QValue q){
		Value value = new Value(this.game.getNumAgents(),this.game.getNumStates());
		Integer stateIndex = state.getId();
		Integer actionPairs = (int) Math.pow(1.0*this.game.getNumActions(), 1.0*this.game.getNumAgents());
		
		Double overallMax = Double.NEGATIVE_INFINITY;
		Double maxOne = 0.0;
		Double maxTwo = 0.0;
		
		for(int p1 = 0; p1<=this.NUM_PROBS;p1++){
			int totalProb1 = p1;	
			for(int p2 = 0; p2<=this.NUM_PROBS-totalProb1;p2++){
				int totalProb2 = totalProb1 + p2;
				for(int p3 = 0; p3<=this.NUM_PROBS-totalProb2;p3++){
					int totalProb3 = totalProb2 + p3;
					for(int p4 = 0; p4<=this.NUM_PROBS-totalProb3;p4++){
						int totalProb4 = totalProb3 + p4;
						for(int p5 = 0; p5<=this.NUM_PROBS-totalProb4;p5++){
							int totalProb5 = totalProb4 + p5;
							for(int p6 = 0; p6<=this.NUM_PROBS-totalProb5;p6++){
								int totalProb6 = totalProb5 + p6;
								for(int p7 = 0; p7<=this.NUM_PROBS-totalProb6;p7++){
									int totalProb7 = totalProb6 + p7;
									for(int p8 = 0; p8<=this.NUM_PROBS-totalProb7;p8++){
										int totalProb8 = totalProb7 + p8;
										for(int p9 = 0; p9<=this.NUM_PROBS-totalProb8;p9++){
											int totalProb9 = totalProb8 + p9;
											for(int p10 = 0; p10<=this.NUM_PROBS-totalProb9;p10++){
												int totalProb10 = totalProb9 + p10;
												for(int p11 = 0; p11<=this.NUM_PROBS-totalProb10;p11++){
													int totalProb11 = totalProb10 + p11;
													for(int p12 = 0; p12<=this.NUM_PROBS-totalProb11;p12++){
														int totalProb12 = totalProb11 + p12;
														for(int p13 = 0; p13<=this.NUM_PROBS-totalProb12;p13++){
															int totalProb13 = totalProb12 + p13;
															for(int p14 = 0; p14<=this.NUM_PROBS-totalProb13;p14++){
																int totalProb14 = totalProb13 + p14;
																for(int p15 = 0; p15<=this.NUM_PROBS-totalProb14;p15++){
																	int totalProb15 = totalProb14 + p15;
																	for(int p16 = 0; p16<=this.NUM_PROBS-totalProb15;p16++){
																		int totalProb16 = totalProb15 + p16;
																		for(int p17 = 0; p17<=this.NUM_PROBS-totalProb16;p17++){
																			int totalProb17 = totalProb16 + p17;
																			for(int p18 = 0; p18<=this.NUM_PROBS-totalProb17;p18++){
																				int totalProb18 = totalProb17 + p18;
																				for(int p19 = 0; p19<=this.NUM_PROBS-totalProb18;p19++){
																					int totalProb19 = totalProb18 + p19;
																					for(int p20 = 0; p20<=this.NUM_PROBS-totalProb19;p20++){
																						int totalProb20 = totalProb19 + p20;
																						for(int p21 = 0; p21<=this.NUM_PROBS-totalProb20;p21++){
																							int totalProb21 = totalProb20 + p21;
																							for(int p22 = 0; p22<=this.NUM_PROBS-totalProb21;p22++){
																								int totalProb22 = totalProb21 + p22;
																								for(int p23 = 0; p23<=this.NUM_PROBS-totalProb22;p23++){
																									int totalProb23 = totalProb22 + p23;
																									for(int p24 = 0; p24<=this.NUM_PROBS-totalProb23;p24++){
																										int totalProb24 = totalProb23 + p24;
																										int p25 = this.NUM_PROBS - totalProb24;
																										
																										Double[] probs = new Double[25];
																										probs[0] = 1.0 * p1 / this.NUM_PROBS;
																										probs[1] = 1.0 * p2 / this.NUM_PROBS;
																										probs[2] = 1.0 * p3 / this.NUM_PROBS;
																										probs[3] = 1.0 * p4 / this.NUM_PROBS;
																										probs[4] = 1.0 * p5 / this.NUM_PROBS;
																										probs[5] = 1.0 * p6 / this.NUM_PROBS;
																										probs[6] = 1.0 * p7 / this.NUM_PROBS;
																										probs[7] = 1.0 * p8 / this.NUM_PROBS;
																										probs[8] = 1.0 * p9 / this.NUM_PROBS;
																										probs[9] = 1.0 * p10 / this.NUM_PROBS;
																										probs[10] = 1.0 * p11 / this.NUM_PROBS;
																										probs[11] = 1.0 * p12 / this.NUM_PROBS;
																										probs[12] = 1.0 * p13 / this.NUM_PROBS;
																										probs[13] = 1.0 * p14 / this.NUM_PROBS;
																										probs[14] = 1.0 * p15 / this.NUM_PROBS;
																										probs[15] = 1.0 * p16 / this.NUM_PROBS;
																										probs[16] = 1.0 * p17 / this.NUM_PROBS;
																										probs[17] = 1.0 * p18 / this.NUM_PROBS;
																										probs[18] = 1.0 * p19 / this.NUM_PROBS;
																										probs[19] = 1.0 * p20 / this.NUM_PROBS;
																										probs[20] = 1.0 * p21 / this.NUM_PROBS;
																										probs[21] = 1.0 * p22 / this.NUM_PROBS;
																										probs[22] = 1.0 * p23 / this.NUM_PROBS;
																										probs[23] = 1.0 * p24 / this.NUM_PROBS;
																										probs[24] = 1.0 * p25 / this.NUM_PROBS;
																										
																										Double valueOne = this.getQSigma(q,0,stateIndex,probs,actionPairs);
																										Double valueTwo = this.getQSigma(q,1,stateIndex,probs,actionPairs);
																										Double totalValue = valueOne + valueTwo;
																										if(totalValue > overallMax){
																											overallMax = totalValue;
																											maxOne = valueOne;
																											maxTwo = valueTwo;
																										}
																										
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		value.set(0, state, maxOne);
		value.set(1, state, maxTwo);
		
		return value;
	}
	
	private Double getQSigma(QValue q, Integer agentIndex, Integer stateIndex, Double[] prob, Integer numActions){
		Double result = 0.0;
		for(int a = 0; a < numActions; a++){
			result = result + prob[a]*q.getDirect(agentIndex,stateIndex,a);
		}
		return result;
	}
	
}
