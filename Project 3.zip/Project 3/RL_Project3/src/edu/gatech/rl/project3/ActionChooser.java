package edu.gatech.rl.project3;

public interface ActionChooser {
	
	public Action getAction();

}
