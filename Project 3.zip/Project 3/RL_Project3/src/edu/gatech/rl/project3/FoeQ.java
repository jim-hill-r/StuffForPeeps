package edu.gatech.rl.project3;

import java.util.ArrayList;
import java.util.List;

public class FoeQ implements SelectionFunction {

	private MarkovGame game;
	private int NUM_PROBS;
	
	public FoeQ(MarkovGame game){
		this.game = game;
		this.NUM_PROBS = 20;
	}
	
	public Value getValue(State state, QValue q){
		Value value = new Value(this.game.getNumAgents(),this.game.getNumStates());
		Integer stateIndex = state.getId();
		List<Double> mins = new ArrayList<Double>();
		mins.add(Double.MAX_VALUE);
		mins.add(Double.MAX_VALUE);
		mins.add(Double.MAX_VALUE);
		mins.add(Double.MAX_VALUE);
		mins.add(Double.MAX_VALUE);
		for(int p1 = 0; p1<=this.NUM_PROBS;p1++){
			int totalProb1 = p1;
			for(int p2 = 0; p2<=this.NUM_PROBS-totalProb1;p2++){
				int totalProb2 = totalProb1 + p2;
				for(int p3 = 0; p3<=this.NUM_PROBS-totalProb2;p3++){
					int totalProb3 = totalProb2 + p3;
					for(int p4 = 0; p4<=this.NUM_PROBS-totalProb3; p4++){
						int totalProb4 = totalProb3 + p4;
						int p5 = this.NUM_PROBS - totalProb4;
						
						
						Double[] probs = new Double[5];
						probs[0] = 1.0 * p1 / this.NUM_PROBS;
						probs[1] = 1.0 * p2 / this.NUM_PROBS;
						probs[2] = 1.0 * p3 / this.NUM_PROBS;
						probs[3] = 1.0 * p4 / this.NUM_PROBS;
						probs[4] = 1.0 * p5 / this.NUM_PROBS;
						
						for(int a2 = 0; a2 < this.game.getNumActions(); a2++){
							Double v = this.getQSigma(stateIndex, q, a2, probs);
							if (v < mins.get(a2)){
								mins.set(a2, v);
							}
						}
					}
				}
			}
		}
		
		Double max = Double.MIN_VALUE;
		for(Double min : mins){
			if(min > max){
				max = min;
			}
		}
		
		value.set(0, state, max);
		value.set(1, state, -1.0 * max);
		
		return value;
	}
	
	private Double getQSigma(Integer stateIndex, QValue q, Integer p2Action, Double[] prob){
		Double result = 0.0;
		for(int a1 = 0; a1 < this.game.getNumActions(); a1++){
			Integer actionIndex = a1 * 5 + p2Action;
			result = result + prob[a1]*q.getDirect(0,stateIndex,actionIndex);
		}
		return result;
	}
	
}
