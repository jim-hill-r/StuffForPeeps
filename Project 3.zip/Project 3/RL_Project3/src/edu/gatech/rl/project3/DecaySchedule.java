package edu.gatech.rl.project3;

public interface DecaySchedule {
	public Double decay(Double currentAlpha);
}
