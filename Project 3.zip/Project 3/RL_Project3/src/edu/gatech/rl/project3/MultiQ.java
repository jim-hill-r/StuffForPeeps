package edu.gatech.rl.project3;

public class MultiQ {
	
	private MarkovGame game;
	private SelectionFunction vF;
	private QUpdate qF;
	private ActionChooser aF;
	private Double gamma;
	private Double alpha;
	private DecaySchedule S;
	private Integer T;
	private State resultState;
	private Action resultAction;
		
	public MultiQ(MarkovGame game, SelectionFunction vF, QUpdate qF, ActionChooser aF, Double gamma, Double alpha, DecaySchedule S, Integer T){
		this.game = game;
		this.vF = vF;
		this.qF = qF;
		this.aF = aF;
		this.gamma = gamma;
		this.alpha = alpha;
		this.S = S;
		this.T = T;
		
		this.resultState = new State(this.game.getNumAgents(),this.game.getNumStates());
		resultState.set(0, 2);
		resultState.set(1, 9);
		this.resultAction = new Action(this.game.getNumAgents(),this.game.getNumActions());
		resultAction.set(0, 3);
		resultAction.set(1, 0);	
	}
	
	public Result run(){
		Result result = new Result();
		
		Double alpha = this.alpha;
		State currentState = this.game.initialState();
		Action currentAction = this.aF.getAction();
		Reward currentReward = this.game.getReward(currentState);
		QValue currentQ = this.qF.initialQ();
		Value currentValue = this.vF.getValue(currentState, currentQ);
		
		Double currentResult = 0.0;
		
		for(int t=0;t<T;t++){
			currentState = this.game.initialState();
			Double previousResult = currentResult;
			Boolean reportResult = false;
			while(!currentState.isTerminal()){
				// simulate actions ai,...,an in state s
				State prevState = currentState.duplicate();
				currentState = this.game.simulate(currentState, currentAction);
				
				// observe rewards R1,...,Rn and next state s'
				currentReward = this.game.getReward(currentState);
	
				// Vi(s') = fi(Q1(s'),...Qn(s'))
				currentValue = this.vF.getValue(currentState, currentQ);
				
				// Qi(s,ahat) = (1-alpha)(Qi(s,ahat) + alpha(1-gamma)R + gamma*Vi(s')
				currentQ = this.qF.getUpdate(prevState, currentAction, currentReward, currentState, currentValue, currentQ, alpha, this.gamma);
				reportResult = reportResult || this.isResult(prevState, currentAction);
				
				// Agents choose actions a1 = a1',...an = an'
				currentAction = this.aF.getAction();
				
				// Decay alpha according to S
				alpha = S.decay(alpha);
			}
			
			// Append iteration result
			if(reportResult){
				currentResult = this.getResult(currentQ);
				result.append(0, t, previousResult, currentResult);
				System.out.println(t);
			}
		}
		
		return result;
	}
	
	private Double getResult(QValue q){
		//Double result = q.getDirect(0, this.resultState.getId(), this.resultAction.get(0)); // For Traditional Q
		Double result = q.get(0, this.resultState, this.resultAction); // For multi agent Q
		return result;
	}
	
	private Boolean isResult(State state, Action action){
		if(state.getId() != this.resultState.getId() ){
			return false;
		}
		if(action.getId() != this.resultAction.getId() ){
			return false;
		}
		return true;
	}
}
