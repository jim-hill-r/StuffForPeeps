package edu.gatech.rl.project3;

import java.util.HashMap;
import java.util.Map;

public class QValue {
	
	Integer numAgents;
	Integer numActions;
	Map<Integer, Map<Integer, Map<Integer, Double>>> values;
	
	public QValue(Integer numAgents, Integer numStates, Integer numActions){
		this.numAgents = numAgents;
		this.numActions = numActions;
		this.values = new HashMap<Integer,Map<Integer, Map<Integer,Double>>>();
		Integer actionPairs = (int) Math.pow(1.0*numActions, 1.0*numAgents);
		Integer statePairs = (int) Math.pow(1.0*numStates, 1.0*numAgents);
		for(int i=0; i<numAgents;i++){
			Map<Integer,Map<Integer,Double>> stateValues = new HashMap<Integer,Map<Integer,Double>>();
			for(int j=0; j<statePairs;j++){
				Map<Integer,Double> stateActionValues = new HashMap<Integer,Double>();
				for(int k=0; k<actionPairs;k++){
					stateActionValues.put(k, 0.0);
				}
				stateValues.put(j, stateActionValues);
			}
			this.values.put(i, stateValues);
		}
	}

	public Double get(Integer agentIndex, State state, Action action){
		Integer actionIndex = action.getId();
		Integer stateIndex = state.getId();
		Double result = this.values.get(agentIndex).get(stateIndex).get(actionIndex);
		return result;
	}
	
	public Double getDirect(Integer agentIndex, Integer stateIndex, Integer actionIndex){
		Double result = this.values.get(agentIndex).get(stateIndex).get(actionIndex);
		return result;
	}
	
	public void set(Integer agentIndex, State state, Action action, Double newValue){
		Integer actionIndex = action.getId();
		Integer stateIndex = state.getId();
		
		Map<Integer, Map<Integer, Double>> stateValues = this.values.get(agentIndex);
		Map<Integer,Double> stateActionValues = stateValues.get(stateIndex);
		stateActionValues.put(actionIndex, newValue);
	}
	
	public void setDirect(Integer agentIndex, Integer stateIndex, Integer actionIndex, Double newValue){
		Map<Integer, Map<Integer, Double>> stateValues = this.values.get(agentIndex);
		Map<Integer,Double> stateActionValues = stateValues.get(stateIndex);
		stateActionValues.put(actionIndex, newValue);
	}
	
	public Double max(Integer agentIndex, State state){
		Integer stateIndex = state.getId();
		Map<Integer,Double> stateActionValues = this.values.get(agentIndex).get(stateIndex);
		Double max = stateActionValues.get(0);
		for(Integer key : stateActionValues.keySet()){
			Double value = stateActionValues.get(key);
			if(value > max){
				max = value;
			}
		}
		return max;
	}
}
