package edu.gatech.rl.project3;

import java.util.HashMap;
import java.util.Map;

public class State {
	
	Integer numAgents;
	Integer numStates;
	Boolean isTerminal;
	Map<Integer, Integer> states;
	
	public State(Integer numAgents, Integer numStates){
		this.states = new HashMap<Integer,Integer>();
		for(int i=0; i<numAgents;i++){
			this.states.put(i,0);
		}
		this.isTerminal = false;
		this.numAgents = numAgents;
		this.numStates = numStates;
	}

	public Integer get(Integer agentIndex){	
		return this.states.get(agentIndex);
	}
	
	public void set(Integer agentIndex, Integer stateIndex){
		this.states.put(agentIndex, stateIndex);
	}
	
	public Integer getId(){
		Integer id = 0;
		for(int i=0;i<this.numAgents;i++){
			Integer agentState = this.get(i);
			id = id + (int)(agentState * Math.pow(this.numStates,this.numAgents - i - 1));
		}
		return id;
	}
	
	public Boolean isTerminal(){
		return isTerminal;
	}
	
	public void setIsTerminal(){
		this.isTerminal = true;
	}
	
	public State duplicate(){
		State copy = new State(this.numAgents,this.numStates);
		copy.isTerminal = this.isTerminal;
		for(Integer key : this.states.keySet()){
			copy.states.put(key, this.states.get(key));
		}
		return copy;
	}
	
	@Override
	public String toString(){
		String result = "STATE(" + this.getId().toString() + ")---";
		for(Integer key : this.states.keySet()){
			result = result + "Agent " + key.toString() + ": " + this.states.get(key) + " | ";
		}
		return result;
	}
}
