package edu.gatech.rl.project3;

import java.util.HashMap;
import java.util.Map;

public class Action {
	
	Integer numAgents;
	Integer numActions;
	Map<Integer, Integer> actions;
	
	public Action(Integer numAgents, Integer numActions){
		this.actions = new HashMap<Integer,Integer>();
		for(int i=0; i<numAgents;i++){
			this.actions.put(i,0);
		}
		this.numAgents = numAgents;
		this.numActions = numActions;
	}

	public Integer get(Integer agentIndex){	
		return this.actions.get(agentIndex);
	}
	
	public void set(Integer agentIndex, Integer actionIndex){
		this.actions.put(agentIndex, actionIndex);
	}
	
	public Integer getId(){
		Integer id = 0;
		for(int i=0;i<this.numAgents;i++){
			Integer agentAction = this.get(i);
			id = id + (int)(agentAction * Math.pow(this.numActions,this.numAgents - i - 1));
		}
		return id;
	}
	
	@Override
	public String toString(){
		String result = "ACTION(" + this.getId().toString() + ")--";
		for(Integer key : this.actions.keySet()){
			result = result + "Agent " + key.toString() + ": " + this.actions.get(key) + " | ";
		}
		return result;
	}
	
}
