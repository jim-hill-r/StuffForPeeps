import gym
import os
from random import randint
import math

class Agent:
	class Result:
		episode = None
		rewards = 0
		initialPotential = None
		finalPotential = None
		shapedRewards = 0

	results = []
	env = None
	weights = None 
	alpha = 0.01
	gamma = 0.5
	phi = 1.0
	trainingResults = None

	def __init__(self, env):
		self.env = env
		# One weight vector for each potential action
		currentDirectory = os.path.dirname(os.path.realpath(__file__))
		initialConditions = currentDirectory + "\\initial.txt"
		self.readAgent(initialConditions)
		#self.weights = []
		#for i in range(0,4):
		#	action = []
		#	for j in range(0,8):
		#		action.append(0)
		#	self.weights.append(action)

	# Vector functions
	def getDotProduct(self, a,b):
		result = 0;
		for i in range(0,8):
			result = result + a[i] * b[i]
		return result

	def addVectors(self, a,b):
		result = [];
		for i in range(0,8):
			result.append(a[i] + b[i])
		return result

	def normalizeVector(self, a):
		total = 0
		for i in range(0,8):
			total = total + abs(a[i])
		for i in range(0,8):
			a[i] = a[i] / total
		return a

	def normalizeVectors(self, vectors):
		total = 0
		for v in vectors:
			for i in range(0,8):
				total = total + abs(v[i])
		for v in vectors:
			for i in range(0,8):
				v[i] = v[i] / total
		return vectors		

	# Q is the linear combination of state and weights for the given action (i.e. X transpose W)
	def getQ(self, s,a):
		#print("A: " + str(a) + "  |  Q: " + str(self.getDotProduct(s,self.weights[a])))
		return self.getDotProduct(s,self.weights[a])

	# Find the best Q value and do that action.
	def getAction(self, state): 
		maxQ = self.getQ(state,0)
		maxA = 0
		for i in range(1,4):
			q = self.getQ(state,i)
			if q > maxQ:
				maxQ = q
				maxA = i
		return maxA, maxQ

	def getTrainingAction(self, state, episode, numEpisodes):
		r = randint(0,1 + numEpisodes / 4)
		if r == 0:
			return randint(0,3)
		if episode % 10 == 0:
			return randint(0,3)
		return self.getAction(state)

	def getPotential(self, state):
		multiplier = 0.5
		xPos = state[0]
		yPos = state[1]
		xVel = state[2]
		yVel = state[3]
		rotPos = state[4]
		rotVel = state[5]
		leftLegTouching = state[6]
		rightLegTouching = state[7]

		xPosPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * xPos)))
		yPosPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * yPos)))
		xVelPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * xVel)))
		yVelPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * yVel)))
		rotPosPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * rotPos)))
		rotVelPotential =  -1 * abs(multiplier / (1 + math.exp(-0.5 * rotVel)))

		#xPosPotential = -1 * multiplier * abs(xPos)
		#yPosPotential = -1 * multiplier * abs(yPos)
		#xVelPotential = -1 * multiplier * abs(xVel)
		#yVelPotential = -1 * multiplier * abs(yVel)
		#rotPosPotential = -1 * multiplier * abs(rotPos)
		#rotVelPotential = -1 * multiplier * abs(rotVel)
		leftLegTouchingPotential = multiplier * leftLegTouching
		rightLegTouchingPotential = multiplier * rightLegTouching

		#return xPosPotential + yPosPotential + xVelPotential + yVelPotential + rotPosPotential + rotVelPotential
		return 0

	def getDirectError(self, currentReward, currentQ, previousQ):
		return currentReward + (self.gamma * currentQ) - previousQ

	def getResidualError(self, currentState, previousState):
		residualError = []
		for i in range(0,8):
			residualError.append((self.phi * self.gamma * currentState[i]) - previousState[i])
		return residualError

	def getWeightUpdate(self, directError, residualError):
		update = []
		for i in range(0,8):
			update.append(-1 * self.alpha * directError * residualError[i])
		return update

	def trainAgent(self, numEpisodes):
		print("Training Baird Agent")
		self.results = []
		for episode in range(numEpisodes):
			currentState = self.env.reset()
			currentAction = 0
			currentQ = self.getQ(currentState,currentAction)
			currentPotential = self.getPotential(currentState)
			episodeResult = self.Result()
			episodeResult.episode = episode
			for t in range(3000):
				# Store previous timestep information
				previousState = currentState
				previousAction = currentAction
				previousQ = currentQ
				previousPotential = currentPotential

				# Get new timestep information
				#currentAction = self.getTrainingAction(currentState, episode, numEpisodes)
				currentAction = self.getAction(currentState)
				currentState, currentReward, done, info = self.env.step(currentAction)
				currentQ = self.getQ(currentState,currentAction)
				episodeResult.rewards = episodeResult.rewards + currentReward

				# Add potential weight shaping to speed training since Baird is slow
				currentPotential = self.getPotential(currentState)
				currentReward = currentReward + (self.gamma * currentPotential) - previousPotential
				episodeResult.shapedRewards = episodeResult.shapedRewards + currentReward

				# Update weights
				directError = self.getDirectError(currentReward,currentQ,previousQ)
				residualError = self.getResidualError(currentState,previousState)
				weightUpdate = self.getWeightUpdate(directError,residualError)
				self.weights[currentAction] = self.addVectors(self.weights[currentAction],weightUpdate)
				if done:
					break

			self.results.append(episodeResult)

	def writeAgent(self, filepath):
		f = open(filepath, 'w')
		for action in self.weights:
			for w in action:
				f.write(str(w) + "\n")
		f.close()

	def writeTrainingResults(self, filepath):
		f = open(filepath, 'w')
		f.write("episode,rewards,initialPotential,finalPotential,shapedRewards\n")
		for result in self.results:
			f.write(str(result.episode) + "," + str(result.rewards) + "," + str(result.initialPotential) + "," + str(result.finalPotential) + "," + str(result.shapedRewards) + "\n")
		f.close()


	def readAgent(self, filepath):
		f = open(filepath, 'r')
		self.weights = []
		for i in range(0,4):
			action = []
			for j in range(0,8):
				action.append(float(f.readline()))
			self.weights.append(action)
		f.close()
