import gym
import os
import BairdAgent

# Agents must include the following functions
#	trainAgent()
#	getAction(obs)

# Actions available
# ACT_NOOP = 0
# ACT_LEFT = 1
# ACT_MAIN = 2
# ACT_RIGHT = 3

# OBS are based on experimentation
# 0: x position
# 1: y position
# 2: x velocity
# 3: y velocity
# 4: rot position
# 5: rot velocity
# 6: left leg touching ground
# 7: right leg touching ground

def runAgent(env, numTrials, agent):
	grandTotalReward = 0;
	for trial in range(numTrials):
		totalReward = 0;
		observation = env.reset()
		for t in range(1000):
			env.render()
			#print(observation)
			action = agent.getAction(observation)
			observation, reward, done, info = env.step(action)
			totalReward = totalReward + reward
			grandTotalReward = grandTotalReward + reward
			if done:
				print("Trial finished after {} timesteps".format(t+1))
				print("Reward: {}".format(totalReward))
				break

	averageReward = grandTotalReward / numTrials
	print("Average Reward: {}".format(averageReward))

env = gym.make('LunarLander-v2')

agent = BairdAgent.Agent(env)

currentDirectory = os.path.dirname(os.path.realpath(__file__))
filepath = currentDirectory + "\\" + "RLAgentData.txt"
agent.readAgent(filepath)

runAgent(env,15,agent)