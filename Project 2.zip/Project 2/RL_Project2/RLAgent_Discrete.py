import gym
import os
from random import randint

class Agent:
	class Result:
		episode = None
		rewards = 0
		initialPotential = None
		finalPotential = None
		shapedRewards = 0

	results = []
	env = None
	qvalue = None
	increment = 0.1 
	offset = None
	alpha = 0.05
	gamma = 0.9
	lambd = 0.3
	trainingResults = None

	def convertStateToIndex(self, s):
		s = s / self.increment
		s = s + self.offset
		s = max(0,min(int(s),self.numStates - 1))
		return s

	def __init__(self, env):
		self.env = env
		# One weight vector for each potential action
		self.qvalue = []
		self.offset = 1 / self.increment
		self.numStates = int(2 / self.increment)
		self.qvalue = []
		for xPos in range(0,self.numStates):
			x = []
			for yPos in range(0,self.numStates):
				y = []
				for xVel in range(0,self.numStates):
					xdot = []
					for yVel in range(0,self.numStates):
						ydot = []
						for rotPos in range(0,self.numStates):
							rot = []
							for rotVel in range(0,self.numStates):
								rotdot = []
								for llt in range(0,2):
									l = []
									for rlt in range(0,2):
										r = []
										for a in range(0,4):
											r.append(0)
										l.append(r)
									rotdot.append(l)
								rot.append(rotdot)
							ydot.append(rot)
						xdot.append(ydot)
					y.append(xdot)
				x.append(y)
			self.qvalue.append(x)

	# Q is a discretized list of states
	def getQ(self, s,a):
		xPos = self.convertStateToIndex(s[0])
		yPos = self.convertStateToIndex(s[1])
		xVel = self.convertStateToIndex(s[2])
		yVel = self.convertStateToIndex(s[3])
		rotPos = self.convertStateToIndex(s[4])
		rotVel = self.convertStateToIndex(s[5])
		leftLegTouching = int(s[6])
		rightLegTouching = int(s[7])
		return self.qvalue[xPos][yPos][xVel][yVel][rotPos][rotVel][leftLegTouching][rightLegTouching][a]

	# Find the best Q value and do that action.
	def getAction(self, obs): 
		maxQ = self.getQ(obs,0)
		maxA = 0
		for i in range(1,4):
			q = self.getQ(obs,i)
			if q > maxQ:
				maxQ = q
				maxA = i
		return maxA

	def getTrainingAction(self, obs, episode, numEpisodes):
		r = randint(0,1 + numEpisodes / 4)
		if r == 0:
			return randint(0,3)
		if episode % 10 == 0:
			return randint(0,3)
		return self.getAction(obs)

	def getUpdate(self, currentReward, previousObs, currentObs, previousAction, currentAction):
		return self.getQ(previousObs,previousAction) + (self.alpha * (currentReward + (self.gamma * self.getQ(currentObs,currentAction)) - self.getQ(previousObs,previousAction)))

	def getPotential(self, obs):
		multiplier = 1
		xPos = obs[0]
		yPos = obs[1]
		xVel = obs[2]
		yVel = obs[3]
		rotPos = obs[4]
		rotVel = obs[5]
		leftLegTouching = obs[6]
		rightLegTouching = obs[7]

		xPosPotential = -1 * multiplier * abs(xPos)
		yPosPotential = -1 * multiplier * abs(yPos)
		xVelPotential = -1 * multiplier * abs(xVel)
		yVelPotential = -1 * multiplier * abs(yVel)
		rotPosPotential = -1 * multiplier * abs(rotPos)
		rotVelPotential = -1 * multiplier * abs(rotVel)
		leftLegTouchingPotential = multiplier * leftLegTouching
		rightLegTouchingPotential = multiplier * rightLegTouching

		#return rotPosPotential + rotVelPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return xPosPotential + yPosPotential + xVelPotential + yVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return rotVelPotential
		return 0

	def trainAgent(self, numEpisodes):
		print("Training RL Discrete Agent")
		self.results = []
		for episode in range(numEpisodes):
			currentObs = self.env.reset()
			currentAction = 0
			episodeResult = self.Result()
			episodeResult.episode = episode
			episodeResult.initialPotential = self.getPotential(currentObs)
			for t in range(3000):
				#self.env.render()
				#print(self.weights)
				# Store previous timestep information
				previousObs = currentObs
				previousAction = currentAction
				# Get new timestep information
				#currentAction = self.getTrainingAction(currentObs, episode, numEpisodes)
				currentAction = self.getAction(currentObs)
				currentObs, currentReward, done, info = self.env.step(currentAction)
				episodeResult.rewards = episodeResult.rewards + currentReward
				# Add potential reward in order to speed training and prevent divergence
				currentReward = currentReward + (self.gamma * self.getPotential(currentObs)) - self.getPotential(previousObs) # self.gamma was removed even though it exists in lecture
				episodeResult.shapedRewards = episodeResult.shapedRewards + currentReward
				# Update qvalue
				update = self.getUpdate(currentReward,previousObs,currentObs,previousAction,currentAction)
				xPos = self.convertStateToIndex(previousObs[0])
				yPos = self.convertStateToIndex(previousObs[1])
				xVel = self.convertStateToIndex(previousObs[2])
				yVel = self.convertStateToIndex(previousObs[3])
				rotPos = self.convertStateToIndex(previousObs[4])
				rotVel = self.convertStateToIndex(previousObs[5])
				leftLegTouching = int(previousObs[6])
				rightLegTouching = int(previousObs[7])
				self.qvalue[xPos][yPos][xVel][yVel][rotPos][rotVel][leftLegTouching][rightLegTouching][previousAction] = update
				if done:
					break
			episodeResult.finalPotential = self.getPotential(currentObs)
			self.results.append(episodeResult)

	def writeAgent(self, filepath):
		f = open(filepath, 'w')
		for xPos in range(0,self.numStates):
			for yPos in range(0,self.numStates):
				for xVel in range(0,self.numStates):
					for yVel in range(0,self.numStates):
						for rotPos in range(0,self.numStates):
							for rotVel in range(0,self.numStates):
								for llt in range(0,2):
									for rlt in range(0,2):
										for a in range(0,4):
											f.write(str(self.qvalue[xPos][yPos][xVel][yVel][rotPos][rotVel][llt][rlt][a]) + "\n")
		f.close()

	def writeTrainingResults(self, filepath):
		f = open(filepath, 'w')
		f.write("episode,rewards,initialPotential,finalPotential,shapedRewards\n")
		for result in self.results:
			f.write(str(result.episode) + "," + str(result.rewards) + "," + str(result.initialPotential) + "," + str(result.finalPotential) + "," + str(result.shapedRewards) + "\n")
		f.close()


	def readAgent(self, filepath):
		f = open(filepath, 'r')
		self.qvalue = []
		for xPos in range(0,self.numStates):
			x = []
			for yPos in range(0,self.numStates):
				y = []
				for xVel in range(0,self.numStates):
					xdot = []
					for yVel in range(0,self.numStates):
						ydot = []
						for rotPos in range(0,self.numStates):
							rot = []
							for rotVel in range(0,self.numStates):
								rotdot = []
								for llt in range(0,2):
									l = []
									for rlt in range(0,2):
										r = []
										for a in range(0,4):
											r.append(float(f.readline()))
										l.append(r)
									rotdot.append(l)
								rot.append(rotdot)
							ydot.append(rot)
						xdot.append(ydot)
					y.append(xdot)
				x.append(y)
			self.qvalue.append(x)
		f.close()
