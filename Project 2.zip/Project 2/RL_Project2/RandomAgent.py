class Agent:
	env = None
	def __init__(self, env):
		self.env = env

	def trainAgent(self):
		print("Training Random Agent") # Random agent requires no training

	def getAction(self, obs):
		return self.env.action_space.sample()