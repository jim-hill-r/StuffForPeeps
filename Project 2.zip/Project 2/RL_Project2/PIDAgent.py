class Agent:
	env = None
	xPosLimit = 0.1
	yPosLimit = 0.0
	xVelLimit = 0.0
	yVelLimit = 0.02
	rotPosLimit = 0.2
	rotVelLimit = 0.0

	def __init__(self, env):
		self.env = env

	def trainAgent(self):
		print("Training Guessing and checking Agent")

	def getAction(self, obs):
		xPos = obs[0]
		yPos = obs[1]
		xVel = obs[2]
		yVel = obs[3]
		rotPos = obs[4]
		rotVel = obs[5]

		#print(obs)
		if rotPos < self.rotPosLimit and rotPos > -1 * self.rotPosLimit:
			if yVel < -1 * self.yVelLimit:
				return 2
			if xPos < -1 * self.xPosLimit:
				return 3
			if xPos > self.xPosLimit:
				return 1
		if rotPos < -1 * self.rotPosLimit:
			return 1
		if rotPos > self.rotPosLimit:
			return 3
		print("Did Nothing")
		return 0