import gym
import os
from random import randint

class Agent:
	class Result:
		episode = None
		rewards = 0
		initialPotential = None
		finalPotential = None
		shapedRewards = 0

	results = []
	env = None
	weights = None 
	alpha = 0.005
	gamma = 0.9
	lambd = 0.3
	trainingResults = None

	def __init__(self, env):
		self.env = env
		# One weight vector for each potential action
		self.weights = []
		for i in range(0,4):
			action = []
			for j in range(0,8):
				action.append(0)
			self.weights.append(action)

	# Vector functions
	def getDotProduct(self, a,b):
		result = 0;
		for i in range(0,8):
			result = result + a[i] * b[i]
		return result

	def addVectors(self, a,b):
		result = [];
		for i in range(0,8):
			result.append(a[i] + b[i])
		return result

	def normalizeVector(self, a):
		total = 0
		for i in range(0,8):
			total = total + abs(a[i])
		for i in range(0,8):
			a[i] = a[i] / total
		return a

	def normalizeVectors(self, vectors):
		total = 0
		for v in vectors:
			for i in range(0,8):
				total = total + abs(v[i])
		for v in vectors:
			for i in range(0,8):
				v[i] = v[i] / total
		return vectors		

	# Q is the linear combination of state and weights for the given action (i.e. X transpose W)
	def getQ(self, s,a):
		#print("A: " + str(a) + "  |  Q: " + str(self.getDotProduct(s,self.weights[a])))
		return self.getDotProduct(s,self.weights[a])

	# Find the best Q value and do that action.
	def getAction(self, obs): 
		maxQ = self.getQ(obs,0)
		maxA = 0
		for i in range(1,4):
			q = self.getQ(obs,i)
			if q > maxQ:
				maxQ = q
				maxA = i
		return maxA

	def getTrainingAction(self, obs, episode, numEpisodes):
		r = randint(0,1 + numEpisodes / 4)
		if r == 0:
			return randint(0,3)
		if episode % 10 == 0:
			return randint(0,3)
		return self.getAction(obs)

	def getStepError(self, currentReward, previousObs, currentObs, previousAction, currentAction):
		return currentReward + (self.gamma * self.getQ(currentObs,currentAction)) - self.getQ(previousObs, previousAction)

	def getEligibility(self, previousEligibity, currentObs):
		currentEligibility = []
		for i in range(0,8):
			currentEligibility.append((self.gamma * self.lambd * previousEligibity[i]) + currentObs[i])
		return currentEligibility

	def getWeightUpdate(self, stepError, currentEligibility):
		dW = []
		for i in range(0,8):
			dW.append(-1 * self.alpha * stepError * currentEligibility[i])
		return dW

	def getPotential(self, obs):
		multiplier = 1
		xPos = obs[0]
		yPos = obs[1]
		xVel = obs[2]
		yVel = obs[3]
		rotPos = obs[4]
		rotVel = obs[5]
		leftLegTouching = obs[6]
		rightLegTouching = obs[7]

		xPosPotential = -1 * multiplier * abs(xPos)
		yPosPotential = -1 * multiplier * abs(yPos)
		xVelPotential = -1 * multiplier * abs(xVel)
		yVelPotential = -1 * multiplier * abs(yVel)
		rotPosPotential = -1 * multiplier * abs(rotPos)
		rotVelPotential = -1 * multiplier * abs(rotVel)
		leftLegTouchingPotential = multiplier * leftLegTouching
		rightLegTouchingPotential = multiplier * rightLegTouching

		#return rotPosPotential + rotVelPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return xPosPotential + yPosPotential + xVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		return xPosPotential + yPosPotential + xVelPotential + yVelPotential + rotPosPotential + rotVelPotential + leftLegTouchingPotential + rightLegTouchingPotential
		#return rotVelPotential
		#return 0

	def trainAgent(self, numEpisodes):
		print("Training RL Agent")
		self.results = []
		for episode in range(numEpisodes):
			currentObs = self.env.reset()
			currentAction = 0
			currentEligibility = [0,0,0,0,0,0,0,0]
			episodeResult = self.Result()
			episodeResult.episode = episode
			episodeResult.initialPotential = self.getPotential(currentObs)
			for t in range(3000):
				#self.env.render()
				#print(self.weights)
				# Store previous timestep information
				previousObs = currentObs
				previousEligibity = currentEligibility
				previousAction = currentAction
				# Get new timestep information
				#currentAction = self.getTrainingAction(currentObs, episode, numEpisodes)
				currentAction = self.getAction(currentObs)
				currentObs, currentReward, done, info = self.env.step(currentAction)
				episodeResult.rewards = episodeResult.rewards + currentReward
				# Add potential reward in order to speed training and prevent divergence
				currentReward = currentReward + (self.gamma * self.getPotential(currentObs)) - self.getPotential(previousObs) # self.gamma was removed even though it exists in lecture
				episodeResult.shapedRewards = episodeResult.shapedRewards + currentReward
				# Update weights
				stepError = self.getStepError(currentReward,previousObs,currentObs,previousAction,currentAction)
				currentEligibility = self.getEligibility(previousEligibity,currentObs)
				weightUpdate = self.getWeightUpdate(stepError,currentEligibility)
				weightUpdate = self.normalizeVector(weightUpdate)
				self.weights[currentAction] = self.addVectors(self.weights[currentAction],weightUpdate)
				self.weights[currentAction] = self.normalizeVector(self.weights[currentAction])
				if done:
					break
			#self.weights = self.normalizeVectors(self.weights)
			episodeResult.finalPotential = self.getPotential(currentObs)
			self.results.append(episodeResult)

	def writeAgent(self, filepath):
		f = open(filepath, 'w')
		for action in self.weights:
			for w in action:
				f.write(str(w) + "\n")
		f.close()

	def writeTrainingResults(self, filepath):
		f = open(filepath, 'w')
		f.write("episode,rewards,initialPotential,finalPotential,shapedRewards\n")
		for result in self.results:
			f.write(str(result.episode) + "," + str(result.rewards) + "," + str(result.initialPotential) + "," + str(result.finalPotential) + "," + str(result.shapedRewards) + "\n")
		f.close()


	def readAgent(self, filepath):
		f = open(filepath, 'r')
		self.weights = []
		for i in range(0,4):
			action = []
			for j in range(0,8):
				action.append(float(f.readline()))
			self.weights.append(action)
		f.close()
