import gym
import os
import datetime
import BairdAgent

def trainAgent(env, episodes, folder, modifier):
	currentDirectory = os.path.dirname(os.path.realpath(__file__))
	agent = BairdAgent.Agent(env)
	print("Training Started: " + str(datetime.datetime.now()) + " on " + str(episodes) + " episodes.")
	agent.trainAgent(episodes)
	print("Training Finished: " + str(datetime.datetime.now()))
	agentfilepath = currentDirectory + folder + "\\RLAgentData" + modifier + ".txt"
	agent.writeAgent(agentfilepath)
	resultsfilepath = currentDirectory + folder + "\\RLResults" + modifier + ".csv"
	agent.writeTrainingResults(resultsfilepath)

env = gym.make('LunarLander-v2')

if True:
	episodes = 100
	trainAgent(env, episodes,"","")

if False:
	for size in range (0,1):
		episodes = 100 * pow(10,size)
		print("Trying episode size: " + str(episodes))
		for i in range(1,2):
			trainAgent(env, episodes,"\\tests\\","_"+str(episodes)+"_"+str(i))