import gym
from Agent import Agent
from random import random, randint, sample
import math
import numpy as np

class QLearner2(Agent):

	epsilon = None
	gamma = None
	batchsize = None

	def __init__(self, epsilon, gamma, batchsize):
		self.epsilon = epsilon
		self.gamma = gamma
		self.batchsize = batchsize

	def writeResults(self, results, filepath):
		f = open(filepath, 'w')
		f.write("Episode" + "," + "Reward")
		f.write("\n")
		for result in results:
			f.write(str(result[0]) + "," + str(result[1]))
			f.write("\n")
		f.close()

	def epsGreedyAction(self, env, state, reduction, estimator):
		action, q = estimator.getAction(state)
		r = random()
		eps = max(self.epsilon * (1 - reduction),0.1)
		if r < (self.epsilon * (1 - reduction)):
			randomAction = env.action_space.sample()
			return randomAction, q
		return action, q

	def epsGreedyTau(self, reduction):
		#return 1
		return 1 + math.floor(20  * (1 - reduction))

	def trainSamples(self, estimator, history, batchsize, bestBuffer):
		batch = sample(history,batchsize)
		bestBatch = sample(bestBuffer,20)
		while len(bestBatch) > 0:
			batch.append(bestBatch.pop(0))
		x_train = []
		y_train = []
		for samp in batch:
			s, a, r, sPrime, term = samp
			tempA, q = estimator.getAction(s)
			maxA, qPrime = estimator.getAction(sPrime)
			if term:
				target = r
			else:
				target = r + (self.gamma * qPrime[maxA])
			y = np.zeros((1,4))
			y[:] = q[:]
			y[0][a] = target
			#print(str(q) + "||||| " + str(target) + "====" + str(y))
			x_train.append(s.reshape(8,))
			y_train.append(y.reshape(4,))

		x_train = np.array(x_train)
		y_train = np.array(y_train)
		estimator.trainBatch(x_train,y_train,batchsize)

	def getReward(self, data):
		return data[3]

	def train(self, env, episodes, estimator, outputFile):
		results = []
		trainingBuffer = []
		bestBuffer = []
		for episode in range(episodes):
			print ("Episode: " + str(episode))
			# Initialize
			state = env.reset()
			action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator);
			tau = 1

			# Loop through steps and doing training
			rewardTotal = 0
			for t in range(1000):
				prevState = state

				# Render occasionally for debugging and growing undestanding
				#if(episode % 1000 == 0):
				#	env.render()
				
				# Choose new action per e-greedy if tau is appropriately small
				tau = tau - 1
				if tau <= 0:
					action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator)
					tau = self.epsGreedyTau(1.0 * episode / episodes)
				
				# Take action step
				state, reward, done, info = env.step(action)
				rewardTotal = rewardTotal + reward

				# Add sample to training buffer
				data = [prevState,action,reward,state,done]
				trainingBuffer.append(data)
				if len(bestBuffer) < 500:
					bestBuffer.append(data)
				elif bestBuffer[0][2] < reward:
					bestBuffer.append(data)
					bestBuffer = sorted(bestBuffer, key=lambda d: d[2])
					bestBuffer.pop(0)
					#print(bestBuffer)
				
				# Train from buffer if buffer full
				if len(trainingBuffer) > 2000:
					self.trainSamples(estimator,trainingBuffer, self.batchsize, bestBuffer)
					for b in range(self.batchsize):
						trainingBuffer.pop(0)

				# Exit loop if done
				if done:
					break
			print("RewardTotal: " + str(rewardTotal))
			results.append([episode,rewardTotal])
		print(bestBuffer)
		self.writeResults(results, outputFile)	
		return estimator
