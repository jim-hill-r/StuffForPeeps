class Agent:
	def train(self, episodes):
		print("Always return zero!")

	def getAction(self):
		return 0