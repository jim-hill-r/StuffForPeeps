import gym
from Agent import Agent
from random import random, randint
import math

class QLearner(Agent):

	potential = None
	epsilon = None
	gamma = None

	def __init__(self, potential, epsilon, gamma):
		self.potential = potential
		self.epsilon = epsilon
		self.gamma = gamma

	def writeResults(self, results, filepath):
		f = open(filepath, 'w')
		f.write("Episode" + "," + "Reward")
		f.write("\n")
		for result in results:
			f.write(str(result[0]) + "," + str(result[1]))
			f.write("\n")
		f.close()

	def epsGreedyAction(self, env, state, reduction, estimator):
		action, q = estimator.getAction(state)
		r = random()
		eps = max(self.epsilon * (1 - reduction),0.1)
		if r < (self.epsilon * (1 - reduction)):
			randomAction = env.action_space.sample()
			return randomAction, q
		return action, q

	def epsGreedyTau(self, reduction):
		return 1
		#return 1 + math.floor(20  * (1 - reduction))

	def trainSamples(self, estimator, buff, posBuff):
		#print("LEARNING!!!!")
		l = len(buff)
		for i in range(50):
			r = randint(0,l-1)
			#print(str(buff[r][0]) + ":" + str(buff[r][1]))
			estimator.trainSample(buff[r][0],buff[r][1])
		l = len(posBuff)
		num = min(l,20)
		for i in range(num):
			r = randint(0,l-1)
			estimator.trainSample(posBuff[r][0],posBuff[r][1])

	def train(self, env, episodes, estimator, outputFile):
		results = []
		trainingBuffer = []
		posBuffer = []
		for episode in range(episodes):
			print ("Episode: " + str(episode))
			# Initialize
			state = env.reset()
			action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator);
			potential = self.potential.get(state)
			tau = 1
			reward = 0

			# Train from buffer
			if len(trainingBuffer) > 1950:
				self.trainSamples(estimator,trainingBuffer,posBuffer)
			while len(trainingBuffer) > 1950:
				trainingBuffer.pop(0)
			while len(posBuffer) > 980:
				posBuffer.pop(0)

			# Loop through steps and doing training
			rewardTotal = 0
			for t in range(2000):
				#previousPotential = potential
				prevReward = reward

				# Render occasionally for debugging and growing undestanding
				#if(episode % 1000 == 0):
				#	env.render()
				
				# Choose new action per e-greedy if tau is appropriately small
				tau = tau - 1
				if tau <= 0:
					action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator)
					tau = self.epsGreedyTau(1.0 * episode / episodes)
				
				# Take action step
				state, reward, done, info = env.step(action)
				
				# Adjust rewards per potential function
				#potential = self.potential.get(state)
				#reward = reward + (self.gamma * potential) - previousPotential
				#if not done:
				#	reward = reward - prevReward
				#print(str(reward))
				rewardTotal = rewardTotal + reward

				# Define estimator target
				aPrime, qPrime = estimator.getAction(state)
				maxQ = qPrime[aPrime]
				target = q
				for n in range(4):
					if math.isnan(target[n]):
						print("NaN found")
						break
				target[action] = reward + (self.gamma * maxQ)
				if done:
					target[action] = reward
					estimator.trainSample(state,target)

				# Add sample to training buffer
				trainingBuffer.append([state,target])
				if reward > 20:
					posBuffer.append([state,target])
					print("POSITIVE REWARD: " + str(reward))
				# Exit loop if done
				if done:
					break
			print("RewardTotal: " + str(rewardTotal))
			results.append([episode,rewardTotal])
		self.writeResults(results, outputFile)	
		return estimator
