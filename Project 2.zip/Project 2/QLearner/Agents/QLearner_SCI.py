import gym
from Agent import Agent
from random import random, randint, sample
import math
import numpy as np

class QLearner_SCI(Agent):

	epsilon = None
	gamma = None
	batchsize = None
	model = None

	def __init__(self, epsilon, gamma, batchsize):
		self.epsilon = epsilon
		self.gamma = gamma
		self.batchsize = batchsize

	def writeResults(self, results, filepath):
		f = open(filepath, 'w')
		f.write("Episode" + "," + "Reward")
		f.write("\n")
		for result in results:
			f.write(str(result[0]) + "," + str(result[1]))
			f.write("\n")
		f.close()

	def epsGreedyAction(self, env, state, reduction,estimator):
		action, q = estimator.getAction(state)
		r = random()
		eps = max(self.epsilon * (1 - reduction),0.1)
		if r < (self.epsilon * (1 - reduction)):
			randomAction = env.action_space.sample()
			return randomAction, q
		return action, q

	def epsGreedyTau(self, reduction):
		#return 1
		return 1 + math.floor(20  * (1 - reduction*2))

	def trainSamples(self, estimator, history, batchsize):
		batch = sample(history,batchsize)
		for samp in batch:
			state, action, reward, nextState, term = samp
			stateAction = np.append(state,action)
			q = estimator.getQ(stateAction)
			nextA, nextQ = estimator.getAction(nextState)
			target = 1.0* reward
			if not term:
				target = 1.0*reward + (self.gamma * nextQ[nextA])	
			estimator.trainSample(stateAction,1.0*target)

	def train(self, env, episodes, estimator, outputFile):
		results = []
		trainingBuffer = []
		for episode in range(episodes):
			print ("Episode: " + str(episode))
			# Initialize
			state = env.reset()
			action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator);
			tau = 1

			# Loop through steps and doing training
			rewardTotal = 0
			for t in range(2000):
				prevState = state

				# Render occasionally for debugging and growing undestanding
				#if(episode % 1000 == 0):
				#	env.render()
				
				# Choose new action per e-greedy if tau is appropriately small
				tau = tau - 1
				if tau <= 0:
					action, q = self.epsGreedyAction(env, state, 1.0 * episode / episodes, estimator)
					tau = self.epsGreedyTau(1.0 * episode / episodes)
				
				# Take action step
				state, reward, done, info = env.step(action)
				rewardTotal = rewardTotal + reward

				# Add sample to training buffer
				trainingBuffer.append([prevState,action,reward,state,done])
				
				# Train from buffer if buffer full
				if len(trainingBuffer) > 2000:
					self.trainSamples(estimator,trainingBuffer, self.batchsize)
					for b in range(self.batchsize):
						trainingBuffer.pop(0)

				# Exit loop if done
				if done:
					break
			print("RewardTotal: " + str(rewardTotal))
			results.append([episode,rewardTotal])
		self.writeResults(results, outputFile)	
		return estimator
