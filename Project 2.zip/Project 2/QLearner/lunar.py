import gym
import os
import datetime
#from Estimators.NN import NN
#from Agents.QLearner2 import QLearner2
from Estimators.NN_SCI import NN_SCI
from Agents.QLearner_SCI import QLearner_SCI

def writeResults(results, filepath):
	f = open(filepath, 'w')
	f.write("Episode" + "," + "Reward")
	f.write("\n")
	for result in results:
		f.write(str(result[0]) + "," + str(result[1]))
		f.write("\n")
	f.close()

def run(env, agent, episodes, outputFile, render):
	results = []
	grandtotal = 0
	for episode in range(episodes):
		state = env.reset()

		rewardTotal = 0
		for t in range(500):
			if render:
				env.render()
			action, maxQ = agent.getAction(state)
			state, reward, done, info = env.step(action)

			rewardTotal = rewardTotal + reward
			if done:
				#print("Trial finished after {} timesteps".format(t+1))
				break
		results.append([episode,rewardTotal])
		grandtotal = grandtotal + rewardTotal

	writeResults(results, outputFile)
	return grandtotal / episodes

starttime = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

currentDirectory = os.path.dirname(os.path.realpath(__file__))
filepath = currentDirectory + "\\Results\\" + starttime + "_Results.txt"
trainingpath = currentDirectory + "\\TrainingResults\\" + starttime + "_TrainingResults.txt"
modelPath = currentDirectory + "\\Models\\" + starttime + "_NN.h5"

env = gym.make('LunarLander-v2')
estimator = NN_SCI(0.00001)
#estimator = NN(0.001, 8, 4)
#estimator = Linear(0.05, 8, 4)
#potential = Potental()
#potential = SlowAndUpright()
#learner = QLearner(potential,0.9,0.995)
#learner = QLearner2(0.9,0.9,50)
learner = QLearner_SCI(0.9,0.9,50)
estimator = learner.train(env, 10000, estimator,trainingpath)
#if False:
#	averageReward = -1000
#	while(averageReward < 0):
#		estimator = learner.train(env, 1000, estimator,trainingpath)
#		averageReward = run(env, estimator, 100, filepath, False)
#		print("Average Reward: " + str(averageReward))

#estimator.saveModel(modelPath)
#estimator.loadModel(modelPath)
averageReward = run(env, estimator, 100, filepath, False)
print("Average Reward: " + str(averageReward))