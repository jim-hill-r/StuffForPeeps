class SlowAndUpright:
	def get(self, state):
		rotPos = state[4]
		yVel = state[3]
		yPos = state[1]

		rotPotential = -1 * abs(rotPos)
		yVelPotential = -1 * abs(yVel)
		yPosPotential = -1 * abs(yPos)
		return yVelPotential + yPosPotential