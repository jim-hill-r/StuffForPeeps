class Potential:
	def get(self, state):
		return 0