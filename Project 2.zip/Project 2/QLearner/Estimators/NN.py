from Estimator import Estimator
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.optimizers import SGD, RMSprop
from keras.models import load_model

class NN(Estimator):

	model = None
	alpha = 0
	numStates = 0
	numActions = 0

	def __init__(self, alpha, numStates, numActions):
		self.alpha = alpha
		self.numStates = numStates
		self.numActions = numActions

		#Input Layer
		model = Sequential()
		model.add(Dense(12, input_shape=(self.numStates,)))
		#model.add(Activation('relu'))

		# Hidden Layer
		#model.add(Dense(14))
		#model.add(Activation('relu'))

		#model.add(Dense(12, init='lecun_uniform'))
		#model.add(Activation('relu'))

		# Output Layer
		model.add(Dense(self.numActions))
		#model.add(Activation('linear'))

		rms = RMSprop(lr=self.alpha)
		model.compile(loss='mse', optimizer=rms)
		self.model = model

	def getAction(self, state):
		q = self.model.predict(state.reshape(1,8), batch_size=1)
		q = q[0]
		maxA = 0
		for a in range(self.numActions):
			if q[a] > q[maxA]:
				maxA = a
		return maxA, q

	def trainSample(self, state, target):
		self.model.train_on_batch(state.reshape(1,8), target.reshape(1,4))

	def trainBatch(self, states, targets, batchsize):
		self.model.train_on_batch(states,targets)

	def saveModel(self, filepath):
		self.model.save(filepath)

	def loadModel(self, filepath):
		self.model = load_model(filepath)