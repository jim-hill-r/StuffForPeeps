class Estimator:

	def getAction(self, state):
		qVector = [0,1,2,3]
		maxA = 3
		return maxA, qVector

	def trainSample(self, state, target):
		print("TODO")

	def saveModel(self, filepath):
		print("TODO")

	def loadModel(self, filepath):
		print("TODO")