from Estimator import Estimator

class Linear(Estimator):

	weights = None
	alpha = 0.05
	numStates = 0
	numActions = 0

	def __init__(self, alpha, numStates, numActions):
		self.weights = []
		self.alpha = alpha
		self.numStates = numStates
		self.numActions = numActions
		for i in range(numActions):
			states = []
			for j in range(numStates):
				states.append(0)
			self.weights.append(states)

	def calcDotProduct(self,a,b):
		result = 0;
		for i in range(self.numStates):
			result = result + a[i] * b[i]
		return result

	def addVectors(self, a,b):
		result = [];
		for i in range(self.numStates):
			result.append(a[i] + b[i])
		return result

	def normalizeVector(self, a):
		total = 0
		for i in range(0,8):
			total = total + abs(a[i])
		for i in range(0,8):
			a[i] = a[i] / total
		return a

	def normalizeVectors(self, vectors):
		total = 0
		for v in vectors:
			for i in range(0,8):
				total = total + abs(v[i])
		for v in vectors:
			for i in range(0,8):
				v[i] = v[i] / total
		return vectors

	def getAction(self, state):
		q = []
		for i in range(self.numActions):
			q.append(self.calcDotProduct(state,self.weights[i]))
		maxA = 0
		for a in range(self.numActions):
			if q[a] > q[maxA]:
				maxA = a
		return maxA, q

	def trainSample(self, state, target):
		update = []
		maxA, q = self.getAction(state)
		for a in range(self.numActions):
			delta = target[a] - q[a]
			for i in range(self.numStates):
				eligibility = 0 + state[i]
				update.append(self.alpha * delta * eligibility)
		self.weights[a] = self.addVectors(update,self.weights[a])
		#self.weights[action] = self.normalizeVector(self.weights[action])
		#self.weights = self.normalizeVectors(self.weights)