from sklearn.neural_network import MLPRegressor
import numpy as np

class NN_SCI():

	model = None

	def __init__(self, alpha):
		self.model = MLPRegressor(hidden_layer_sizes=(12), alpha = alpha, warm_start = True, max_iter=2)
		iState = np.array([[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0,2],[0,0,0,0,0,0,0,0,3]])
		iTarget = np.array([0,0,0,0])
		self.model.fit(iState,iTarget)

	def getAction(self, state):
		q = []
		for a in range(0,4):
			stateAction = np.append(state,a)
			p = self.model.predict(stateAction.reshape(1,9))
			q.append(p[0])
		maxA = 0
		for a in range(4):
			if q[a] > q[maxA]:
				maxA = a
		return maxA, q

	def getQ(self, state):
		return self.model.predict(state.reshape(1,9))

	def trainSample(self, state, target):
		iTarget = np.array([target])
		self.model.fit(state.reshape(1,9),iTarget)