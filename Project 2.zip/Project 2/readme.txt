RL_Project2
8803 Reinforcement Learning - Project 2 Lunar Lander

PRESENTATION LINK: http://youtu.be/fSUWlHJk8v4?hd=1

GITHUB LINK: https://github.gatech.edu/jhill302/RL_Project2

HOW TO RUN THE CODE:

1) Pull or download the git repo into a local folder
2) Enter the folder named QLearner
3) In command line, type python lunar.py

This will run the training run followed by 100 test runs.
The output will end up in the folder results and trainingresults.

ADDITIONAL NOTES:

The folder RL_Project2 is actually the first attempt using TD_Lambda as described in paper
The folder Agents actually has the qlearner algorithms. QLearner_SCI is the best one to inspect and is based on SKLearn. QLearner and QLearner2 are Keras implementations. Agent is the base class (i.e. interface).
The folder Estimators has all the estimators. NN_SCI is the best one to inspect. NN is Keras implementation. Linear is the linear combiantion implementation. Estimator is the base class (i.e. interface).
The folder Potentials has the potential functions. Not used in final submission.
The Keras implementation saves its models to the models folder for use later.
Even though this was all designed to work together interchangablely, eleventh hour changes may have broken various implementations. The only one guaranteed to work is the one implemented in lunar.py which is the SKLearn version.
If there are any issues, please email jhill302@gatech.edu or jimhill84@gmail.com.